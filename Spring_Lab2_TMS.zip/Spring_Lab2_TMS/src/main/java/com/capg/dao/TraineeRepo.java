package com.capg.dao;

import org.springframework.data.repository.CrudRepository;

import com.capg.model.Trainee;

public interface TraineeRepo extends CrudRepository<Trainee, Integer> {

}
